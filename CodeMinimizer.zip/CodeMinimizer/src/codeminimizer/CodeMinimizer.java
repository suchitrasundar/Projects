/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codeminimizer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Suchitra Sundar
 */
public class CodeMinimizer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here
        try{
			File file = new File("C://Users//Suchitra Sundar//Documents//NetBeansProjects//CodeMinimizer//src//codeminimizer/input.txt");
			BufferedReader reader = new BufferedReader(new FileReader (file));
			StringBuilder stringBuilder = new StringBuilder();
			String line = null;
			String ls = System.getProperty("line.separator");
			while ((line = reader.readLine()) != null) {
				stringBuilder.append(line);
				stringBuilder.append(ls);
			}
			String tokens[] = stringBuilder.toString().split("[^a-zA-Z]+");
			Map<String, Long> tokenVsIndex = new HashMap<>();
			Long index = 0L;
			for(String token: tokens){
				if(token.isEmpty()){
					continue;
				}
				if(!tokenVsIndex.containsKey(token)){
					tokenVsIndex.put(token, index);
				}
				index++;
			}
			
			for(String token: tokenVsIndex.keySet()){
				String replace = "$" + tokenVsIndex.get(token);
				int j = stringBuilder.indexOf(token, 0);
				
				while(!isNotSubString(stringBuilder, token, j)){
					j = stringBuilder.indexOf(token, j);
					if(j == -1){
						break;
					}
					j += token.length();
				}
				if(j == -1 || j > stringBuilder.length()){
					continue;
				}
				j += 1;
				
				while((j = stringBuilder.indexOf(token, j)) != -1){
					if(isNotSubString(stringBuilder, token, j))
						stringBuilder.replace(j, j + token.length(), replace);
					j += token.length();
				}
			}
			
			System.out.print(stringBuilder);
			
		}finally{
			
		}
        
    }
    private static boolean isNotSubString(StringBuilder strBuilder, String token, int pos){
		if(pos > 0){
			if(isChar(strBuilder.charAt(pos-1))){
				return false;
			}
		}
		if(pos + token.length() < strBuilder.length()){
			if(isChar(strBuilder.charAt(pos+token.length()))){
				return false;
			}
			return true;
		}
		if(pos + token.length() == strBuilder.length()){
			return true;
		}
		return false;
	}
	
	private static boolean isChar(char c){
		return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
	}
    
}
